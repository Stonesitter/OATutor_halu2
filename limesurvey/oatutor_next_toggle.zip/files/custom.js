// scripts/custom.js in your LimeSurvey theme
(function () {
  function $q(sel) { return document.querySelector(sel); }
  function hideNext() {
    var $ = window.jQuery;
    if ($) {
      $("#ls-button-submit,#ls-button-next,button[name='move'][type='submit']").hide();
    }
  }
  function showNext() {
    var $ = window.jQuery;
    if ($) {
      $("#ls-button-submit,#ls-button-next,button[name='move'][type='submit']").show();
    }
  }

  function initOATutorIntegration() {
    var iframe = document.getElementById("oatutor-frame");
    if (!iframe) return; // this page/question doesn't use OATutor

    // 1) Hide Next immediately
    hideNext();

    // 2) Generate a per-page token
    var token = (window.crypto && crypto.randomUUID) ? crypto.randomUUID()
              : (Date.now() + Math.random()).toString(36);

    // 3) Build iframe src using data attributes from the question markup
    var base = iframe.dataset.oatutorBase || "";     // e.g. https://stonesitter.github.io/OATutor_halu2/
    var route = iframe.dataset.oatutorRoute || "";   // e.g. #/courses/4/lessons/1
    if (base) {
      iframe.src = base
        + "?parentOrigin=" + encodeURIComponent(location.origin)
        + "&pmToken=" + encodeURIComponent(token)
        + route;
    }

    // 4) Listen for completion from OATutor (postMessage)
    var ALLOWED_CHILD_ORIGINS = [
      "https://stonesitter.github.io"   // adjust if you host elsewhere
    ];
    window.addEventListener("message", function (e) {
      if (ALLOWED_CHILD_ORIGINS.length && !ALLOWED_CHILD_ORIGINS.includes(e.origin)) return;
      var d = e.data || {};
      if (d.type === "OATUTOR_COMPLETE" && d.token === token) {
        showNext();
      }
    });
  }

  // Run on each survey page load
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initOATutorIntegration);
  } else {
    initOATutorIntegration();
  }
})();
